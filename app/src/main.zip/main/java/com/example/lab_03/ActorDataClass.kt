package com.example.lab_03

data class ActorDataClass(
    val id: Int,
    val name: String,
    val rating: Int,
    val details: String,
    val image: Int,
    val image_Preview: Int
)